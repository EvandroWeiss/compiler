/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIBS;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author efw
 * 
 * @see classe para a manipulação de arquivos texto. As funcionalidades vão sendo 
 *      implementadas cfe. a necessidade de uso
 */
public class TextFile {

    private Scanner scanner;
    private String src;
    private String buffer;

    public TextFile(String src) {
        this.src = src;
        buffer = "";

    }

    //For now, this open all content for once
    public boolean open() {
        try {
            scanner = new Scanner(new File(src));
            scanner.useDelimiter("/n");

        } catch (FileNotFoundException ex) {
            Logger.getLogger(TextFile.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    public char nextChar() {
        updateBuffer();
        char c = buffer.charAt(0);
        buffer = buffer.substring(1);
        return c;
    }

    public boolean hasNextChar() {
        updateBuffer();
        return !(buffer.length() == 0);
    }

    public String getContent() {
        String s = "";
        while (hasNextChar()) {
            s += buffer;
            buffer = "";
        }
        return s;
    }

    public void setDelimiter(String delimiter) {
        scanner.useDelimiter(delimiter);
    }

    public String get() {
        updateBuffer();
        String ret = buffer;
        buffer = "";
        updateBuffer();
        return ret;
    }

    public String[] getAll() {
        List<String> contentList = new ArrayList<>();
        while(hasNextChar()){
            contentList.add(get());
        }
        return contentList.toArray(new String[contentList.size()]);
    }

    private void updateBuffer() {
        if (buffer.length() == 0 && scanner.hasNext()) {
            buffer = scanner.next();
        }
    }

}
