/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIBS;

import CONTROL.TokenType;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import netscape.javascript.JSObject;

/**
 *
 * @author efw
 */
public class LexicalAnalysis {

    private TextFile sourceCode;
    private TokenType[] tokens;
    private TokenType tokenTypeError;
    private String lineBuffer;

    public LexicalAnalysis(String sourceCodeFile, String sourceDefinitionFile) {
        //definindo TokenType padrão para erro de reconhecimento
        defineDefaultTokenTypeError();

        //lendo o arquivo de definições de marcas
        TextFile tf = new TextFile(sourceDefinitionFile);
        tf.open();
        tf.setDelimiter("\n");
        String str = tf.getContent();

        //defnindo os objetos TokenType de acordo com o arquivo de definição de marcas
        Gson json = new Gson();
        tokens = json.fromJson(str, TokenType[].class);

        //definindo o objeto Pattern para cada tokenType definido, conforme o regex
        for (TokenType token : tokens) {
            Pattern pattern = Pattern.compile(token.getRegex());
            token.setPattern(pattern);
        }

        //lendo o arquivo fonte a ser analisado
        sourceCode = new TextFile(sourceCodeFile);
        sourceCode.open();
        sourceCode.setDelimiter("\n");
        lineBuffer = sourceCode.get();
    }

    public Token nextToken() {
        //verificando a necessidade de alimentar o buffer de entrada
        if (lineBuffer.length() == 0) {
            lineBuffer = sourceCode.get();
        }
        //caso já percorreu todo o código
        if (lineBuffer.length() == 0) {
            return null;
        }
        //obtendo os Matcher para cada TokenType 
        Matcher mathers[] = createTokensMatcher();
        //obtendo o indice referente ao TokenType escolhido
        int index = chooseToken(mathers);

        //obtendo a descrição do token e retirando os caracteres do buffer de entrada.
        String description;
        if (index == -1) {//caso não casou com nenhum tipo significa que o char não está presente no alfabeto da linguagem
            
            description = lineBuffer.substring(0, 1);
            lineBuffer = lineBuffer.substring(1);
        } else {
            description = lineBuffer.substring(0, mathers[index].end());
            lineBuffer = lineBuffer.substring(mathers[index].end());
        }

        //definindo o objeto Token 
        Token token = new Token();
        token.setTokenType((index == -1) ? tokenTypeError : tokens[index]);
        token.setDescription(description);

        return token;
    }

    private Matcher[] createTokensMatcher() {
        //definindo e retornando array de objetos Matcher já configurados para uso
        //lembrar que para os TokenType que não casam com os primeiros caracteres em buffer,
        // o seu respectivo Mattcher será null
        Matcher matchers[] = new Matcher[tokens.length];
        for (int i = 0; i < tokens.length; i++) {
            TokenType token = tokens[i];
            matchers[i] = token.match(lineBuffer);
        }
        return matchers;
    }

    /**
     * @see A lógica para a escolha do tipo de token: - inicio da string combina
     * com regex to token - em caso de varias combinações com regex, a
     * combinação de maior tamanho é escolhida - em caso de várias combinações
     * com regex e com mesmo comprimento, o definido primeiro é escolhido
     * @return index of de selected token. -1 in case of no matched token
     */
    private int chooseToken(Matcher[] matchers) {
        int selected = -1;

        for (int i = 0; i < matchers.length; i++) {
            Matcher matcher = matchers[i];

            if (matcher != null) {//se a string casou
                if (selected == -1) {//se esse foi o primeiro a casar
                    selected = i;
                } else if (matchers[selected].end() < matcher.end()) { // definição de preferencia à string maior
                    selected = i;
                }
            }
        }

        return selected;
    }

    private void defineDefaultTokenTypeError() {
        tokenTypeError = new TokenType();
        tokenTypeError.setName("error");
        tokenTypeError.setDescription("Não foi possível encontrar definição para o token.");
    }

    /**
     * @return the tokenTypeError
     */
    public TokenType getTokenTypeError() {
        return tokenTypeError;
    }

    /**
     * @param tokenTypeError the tokenTypeError to set
     */
    public void setTokenTypeError(TokenType tokenTypeError) {
        this.tokenTypeError = tokenTypeError;
    }

}
