/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROL;

import LIBS.LexicalAnalysis;
import LIBS.TextFile;
import LIBS.Token;

/**
 *
 * @author efw
 */
public class Main {

    public static void main(String[] args) {
        LexicalAnalysis la = new LexicalAnalysis("/home/efw/NetBeansProjects/Compilador/src/CONTROL/file.txt", "/home/efw/NetBeansProjects/Compilador/src/CONTROL/lexical_definition.json");
        Token token = la.nextToken();
        while (token != null) {
            System.out.println(token.getTokenType().getName() + ": " + token.getDescription());
            token = la.nextToken();
        }

    }
}
